# Histórias do Coração — Novo Nordisk
## Filtro automático de vídeo P&B

Este site recebe vídeos, aplica filtro preto e branco + texto "Histórias do coração" e retorna o vídeo pronto para o Instagram.

---

## Como instalar e rodar localmente

### Pré-requisitos
- Node.js 18+ instalado (https://nodejs.org)
- FFmpeg instalado no sistema

#### Instalar FFmpeg:
- **Mac:** `brew install ffmpeg`
- **Windows:** Baixar em https://ffmpeg.org/download.html
- **Linux:** `sudo apt install ffmpeg`

### Passos

```bash
# 1. Entre na pasta do projeto
cd novo-nordisk-filter

# 2. Instale as dependências
npm install

# 3. Rode o servidor
npm start

# 4. Abra no navegador
# http://localhost:3000
```

---

## Como publicar na internet (Vercel) — GRÁTIS

### Opção 1: Via GitHub (recomendado)

1. Crie uma conta em https://github.com e https://vercel.com
2. Crie um repositório no GitHub e faça upload desta pasta
3. No Vercel, clique em "New Project" → importe o repositório
4. Vercel detecta automaticamente o projeto Node.js
5. Clique em "Deploy"
6. Seu link fica disponível em: `https://seu-projeto.vercel.app`

### Opção 2: Via Vercel CLI

```bash
npm install -g vercel
vercel login
vercel --prod
```

---

## Estrutura do projeto

```
novo-nordisk-filter/
├── index.html      # Interface do usuário (cores Novo Nordisk)
├── server.js       # Servidor Node.js + processamento FFmpeg
├── overlay.png     # Overlay transparente com vinheta + texto
├── package.json    # Dependências
└── README.md       # Este arquivo
```

---

## Como funciona o processamento

1. Usuário faz upload do vídeo (MP4/MOV)
2. FFmpeg aplica:
   - Redimensiona para 1080x1920 (9:16 — formato Reels)
   - Remove todas as cores (grayscale)
   - Sobrepõe o PNG com vinheta + "Histórias do coração"
3. Retorna o MP4 processado para download

---

## Suporte
Para dúvidas sobre o projeto, contate o time de comunicação.
